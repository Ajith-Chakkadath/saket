"use client"
import { useState } from "react"
import AdminRegistration from "@/components/admin/admin-registration"
import AdminLogin from "@/components/admin/admin-login"
import ResetPassword from "@/components/admin/reset-password"
import EmployeeManagement from "@/components/employee/employee-management"

export default function Home() {
  const [currentPage, setCurrentPage] = useState("login")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  const handlePageChange = (page) => {
    setCurrentPage(page)
  }

  const handleLogin = () => {
    setIsLoggedIn(true)
    setCurrentPage("employeeManagement")
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setCurrentPage("login")
  }

  return (
    <main className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-primary">Employee Details Admin System</h1>
          {isLoggedIn && (
            <button onClick={handleLogout} className="mt-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">
              Logout
            </button>
          )}
        </header>

        {currentPage === "login" && (
          <AdminLogin
            onLogin={handleLogin}
            onResetPassword={() => handlePageChange("resetPassword")}
            onRegister={() => handlePageChange("register")}
          />
        )}

        {currentPage === "register" && (
          <AdminRegistration
            onRegistrationSuccess={() => handlePageChange("login")}
            onBackToLogin={() => handlePageChange("login")}
          />
        )}

        {currentPage === "resetPassword" && (
          <ResetPassword
            onResetSuccess={() => handlePageChange("login")}
            onBackToLogin={() => handlePageChange("login")}
          />
        )}

        {currentPage === "employeeManagement" && isLoggedIn && <EmployeeManagement />}
      </div>
    </main>
  )
}

