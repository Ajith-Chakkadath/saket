"use client"
import { useState } from "react"
import EmployeeCreate from "./employee-create"
import EmployeeSearch from "./employee-search"
import EmployeeUpdate from "./employee-update"
import EmployeeDelete from "./employee-delete"
import EmployeeList from "./employee-list"

export default function EmployeeManagement() {
  const [activeTab, setActiveTab] = useState("create")

  // Generate mock employee data
  const generateMockEmployees = () => {
    const departments = ["Engineering", "Marketing", "Sales", "HR", "Finance"]
    const countries = ["USA", "Canada", "UK", "India", "Australia"]
    const genders = ["Male", "Female", "Other"]

    const employees = []
    for (let i = 1; i <= 50; i++) {
      employees.push({
        id: i.toString().padStart(3, "0"),
        name: `Employee ${i}`,
        department: departments[Math.floor(Math.random() * departments.length)],
        email: `employee${i}@example.com`,
        phone: `${Math.floor(1000000000 + Math.random() * 9000000000)}`,
        gender: genders[Math.floor(Math.random() * genders.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        address: `${Math.floor(100 + Math.random() * 900)} Main St, City, State`,
      })
    }
    return employees
  }

  // State to store employee data
  const [employees, setEmployees] = useState(generateMockEmployees())

  // Function to add a new employee
  const addEmployee = (employee) => {
    setEmployees([...employees, employee])
  }

  // Function to update an employee
  const updateEmployee = (updatedEmployee) => {
    setEmployees(employees.map((emp) => (emp.id === updatedEmployee.id ? updatedEmployee : emp)))
  }

  // Function to delete an employee
  const deleteEmployee = (id) => {
    setEmployees(employees.filter((emp) => emp.id !== id))
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Employee Management</h2>

      <div className="mb-6">
        <div className="flex border-b">
          <button
            className={`px-4 py-2 ${activeTab === "create" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"}`}
            onClick={() => setActiveTab("create")}
          >
            Create Employee
          </button>
          <button
            className={`px-4 py-2 ${activeTab === "search" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"}`}
            onClick={() => setActiveTab("search")}
          >
            Search Employee
          </button>
          <button
            className={`px-4 py-2 ${activeTab === "update" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"}`}
            onClick={() => setActiveTab("update")}
          >
            Update Employee
          </button>
          <button
            className={`px-4 py-2 ${activeTab === "delete" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"}`}
            onClick={() => setActiveTab("delete")}
          >
            Delete Employee
          </button>
          <button
            className={`px-4 py-2 ${activeTab === "list" ? "border-b-2 border-blue-500 text-blue-500" : "text-gray-500"}`}
            onClick={() => setActiveTab("list")}
          >
            Employee List
          </button>
        </div>
      </div>

      {activeTab === "create" && <EmployeeCreate employees={employees} onAddEmployee={addEmployee} />}

      {activeTab === "search" && <EmployeeSearch employees={employees} />}

      {activeTab === "update" && <EmployeeUpdate employees={employees} onUpdateEmployee={updateEmployee} />}

      {activeTab === "delete" && <EmployeeDelete employees={employees} onDeleteEmployee={deleteEmployee} />}

      {activeTab === "list" && <EmployeeList employees={employees} />}
    </div>
  )
}

