"use client"
import { useState } from "react"

export default function EmployeeSearch({ employees }) {
  const [searchId, setSearchId] = useState("")
  const [searchError, setSearchError] = useState("")
  const [searchResult, setSearchResult] = useState(null)

  const handleSearchChange = (e) => {
    setSearchId(e.target.value)
    setSearchError("")
    setSearchResult(null)
  }

  const validateSearch = () => {
    if (!searchId) {
      setSearchError("Employee ID is required")
      return false
    }

    if (!/^\d+$/.test(searchId)) {
      setSearchError("Employee ID must be a number")
      return false
    }

    return true
  }

  const handleSearch = () => {
    if (validateSearch()) {
      // Find employee by ID
      const employee = employees.find((emp) => emp.id === searchId)

      if (employee) {
        setSearchResult(employee)
      } else {
        setSearchError("Employee details not matched with records")
      }
    }
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Search Employee</h3>

      <div className="mb-6">
        <div className="flex items-end space-x-4">
          <div className="flex-grow">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="searchId">
              Employee ID*
            </label>
            <input
              id="searchId"
              type="text"
              className={`w-full px-3 py-2 border rounded-md ${searchError ? "border-red-500" : "border-gray-300"}`}
              value={searchId}
              onChange={handleSearchChange}
              placeholder="Enter Employee ID"
            />
            {searchError && <p className="text-red-500 text-xs mt-1">{searchError}</p>}
          </div>
          <button
            type="button"
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
            onClick={handleSearch}
          >
            Search
          </button>
        </div>
      </div>

      {searchResult && (
        <div className="mt-6">
          <h4 className="text-lg font-semibold mb-2">Employee Details</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-gray-200">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b">Employee ID</th>
                  <th className="py-2 px-4 border-b">Name</th>
                  <th className="py-2 px-4 border-b">Department</th>
                  <th className="py-2 px-4 border-b">Email</th>
                  <th className="py-2 px-4 border-b">Phone</th>
                  <th className="py-2 px-4 border-b">Gender</th>
                  <th className="py-2 px-4 border-b">Country</th>
                  <th className="py-2 px-4 border-b">Address</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-2 px-4 border-b">{searchResult.id}</td>
                  <td className="py-2 px-4 border-b">{searchResult.name}</td>
                  <td className="py-2 px-4 border-b">{searchResult.department}</td>
                  <td className="py-2 px-4 border-b">{searchResult.email}</td>
                  <td className="py-2 px-4 border-b">{searchResult.phone}</td>
                  <td className="py-2 px-4 border-b">{searchResult.gender}</td>
                  <td className="py-2 px-4 border-b">{searchResult.country}</td>
                  <td className="py-2 px-4 border-b">{searchResult.address}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

