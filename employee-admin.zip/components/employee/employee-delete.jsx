"use client"
import { useState } from "react"

export default function EmployeeDelete({ employees, onDeleteEmployee }) {
  const [searchId, setSearchId] = useState("")
  const [searchError, setSearchError] = useState("")
  const [employee, setEmployee] = useState(null)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [deleteStatus, setDeleteStatus] = useState(null)

  const handleSearchChange = (e) => {
    setSearchId(e.target.value)
    setSearchError("")
    setEmployee(null)
    setShowConfirmation(false)
    setDeleteStatus(null)
  }

  const validateSearch = () => {
    if (!searchId) {
      setSearchError("Employee ID is required")
      return false
    }

    if (!/^\d+$/.test(searchId)) {
      setSearchError("Employee ID must be a number")
      return false
    }

    return true
  }

  const handleSearch = () => {
    if (validateSearch()) {
      // Find employee by ID
      const foundEmployee = employees.find((emp) => emp.id === searchId)

      if (foundEmployee) {
        setEmployee(foundEmployee)
      } else {
        setSearchError("Employee details not matched with records")
      }
    }
  }

  const handleDelete = () => {
    setShowConfirmation(true)
  }

  const confirmDelete = () => {
    // Simulate API call
    setTimeout(() => {
      onDeleteEmployee(employee.id)
      setDeleteStatus("success")
      setShowConfirmation(false)
      setEmployee(null)

      // Clear success message after a delay
      setTimeout(() => {
        setDeleteStatus(null)
      }, 3000)
    }, 1000)
  }

  const cancelDelete = () => {
    setShowConfirmation(false)
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Delete Employee</h3>

      {deleteStatus === "success" && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          Employee ID {searchId} details successfully deleted!
        </div>
      )}

      <div className="mb-6">
        <div className="flex items-end space-x-4">
          <div className="flex-grow">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="searchId">
              Employee ID*
            </label>
            <input
              id="searchId"
              type="text"
              className={`w-full px-3 py-2 border rounded-md ${searchError ? "border-red-500" : "border-gray-300"}`}
              value={searchId}
              onChange={handleSearchChange}
              placeholder="Enter Employee ID"
            />
            {searchError && <p className="text-red-500 text-xs mt-1">{searchError}</p>}
          </div>
          <button
            type="button"
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
            onClick={handleSearch}
          >
            Search
          </button>
        </div>
      </div>

      {employee && !showConfirmation && !deleteStatus && (
        <div className="mt-6">
          <h4 className="text-lg font-semibold mb-2">Employee Details</h4>
          <div className="overflow-x-auto mb-4">
            <table className="min-w-full bg-white border border-gray-200">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b">Employee ID</th>
                  <th className="py-2 px-4 border-b">Name</th>
                  <th className="py-2 px-4 border-b">Department</th>
                  <th className="py-2 px-4 border-b">Email</th>
                  <th className="py-2 px-4 border-b">Phone</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-2 px-4 border-b">{employee.id}</td>
                  <td className="py-2 px-4 border-b">{employee.name}</td>
                  <td className="py-2 px-4 border-b">{employee.department}</td>
                  <td className="py-2 px-4 border-b">{employee.email}</td>
                  <td className="py-2 px-4 border-b">{employee.phone}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
              onClick={handleDelete}
            >
              Delete
            </button>
          </div>
        </div>
      )}

      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h4 className="text-lg font-semibold mb-4">Confirm Delete</h4>
            <p className="mb-6">Are you sure you want to delete employee with ID {employee.id}?</p>
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                onClick={cancelDelete}
              >
                Cancel
              </button>
              <button
                type="button"
                className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
                onClick={confirmDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

