"use client"
import { useState } from "react"

export default function EmployeeUpdate({ employees, onUpdateEmployee }) {
  const [searchId, setSearchId] = useState("")
  const [searchError, setSearchError] = useState("")
  const [employee, setEmployee] = useState(null)
  const [formData, setFormData] = useState({
    email: "",
    phone: "",
    country: "",
    address: "",
  })
  const [errors, setErrors] = useState({})
  const [updateStatus, setUpdateStatus] = useState(null)

  // List of countries for dropdown
  const countries = ["USA", "Canada", "UK", "India", "Australia", "Germany", "France", "Japan", "China", "Brazil"]

  const handleSearchChange = (e) => {
    setSearchId(e.target.value)
    setSearchError("")
    setEmployee(null)
    setUpdateStatus(null)
  }

  const validateSearch = () => {
    if (!searchId) {
      setSearchError("Employee ID is required")
      return false
    }

    if (!/^\d+$/.test(searchId)) {
      setSearchError("Employee ID must be a number")
      return false
    }

    return true
  }

  const handleSearch = () => {
    if (validateSearch()) {
      // Find employee by ID
      const foundEmployee = employees.find((emp) => emp.id === searchId)

      if (foundEmployee) {
        setEmployee(foundEmployee)
        setFormData({
          email: foundEmployee.email,
          phone: foundEmployee.phone,
          country: foundEmployee.country,
          address: foundEmployee.address,
        })
      } else {
        setSearchError("Employee details not matched with records")
      }
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Clear error for this field when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      })
    }
  }

  const validateForm = () => {
    const newErrors = {}

    // Required field validation
    Object.keys(formData).forEach((key) => {
      if (!formData[key]) {
        newErrors[key] = `${key.charAt(0).toUpperCase() + key.slice(1)} is required`
      }
    })

    // Email validation
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email format"
    }

    // Phone validation
    if (formData.phone && !/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = "Phone number must be 10 digits"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (validateForm()) {
      // Create updated employee object
      const updatedEmployee = {
        ...employee,
        ...formData,
      }

      // Simulate API call
      setTimeout(() => {
        onUpdateEmployee(updatedEmployee)
        setUpdateStatus("success")

        // Clear success message after a delay
        setTimeout(() => {
          setUpdateStatus(null)
        }, 3000)
      }, 1000)
    } else {
      setUpdateStatus("error")
    }
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Update Employee</h3>

      <div className="mb-6">
        <div className="flex items-end space-x-4">
          <div className="flex-grow">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="searchId">
              Employee ID*
            </label>
            <input
              id="searchId"
              type="text"
              className={`w-full px-3 py-2 border rounded-md ${searchError ? "border-red-500" : "border-gray-300"}`}
              value={searchId}
              onChange={handleSearchChange}
              placeholder="Enter Employee ID"
            />
            {searchError && <p className="text-red-500 text-xs mt-1">{searchError}</p>}
          </div>
          <button
            type="button"
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
            onClick={handleSearch}
          >
            Search
          </button>
        </div>
      </div>

      {employee && (
        <div className="mt-6">
          {updateStatus === "success" && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
              Employee updated successfully!
            </div>
          )}

          {updateStatus === "error" && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              Failed to update employee. Please check the form and try again.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="id">
                  Employee ID
                </label>
                <input
                  id="id"
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                  value={employee.id}
                  disabled
                />
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">
                  Employee Name
                </label>
                <input
                  id="name"
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                  value={employee.name}
                  disabled
                />
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="department">
                  Department
                </label>
                <input
                  id="department"
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                  value={employee.department}
                  disabled
                />
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="gender">
                  Gender
                </label>
                <input
                  id="gender"
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                  value={employee.gender}
                  disabled
                />
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                  Email*
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className={`w-full px-3 py-2 border rounded-md ${errors.email ? "border-red-500" : "border-gray-300"}`}
                  value={formData.email}
                  onChange={handleChange}
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="phone">
                  Phone Number*
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  className={`w-full px-3 py-2 border rounded-md ${errors.phone ? "border-red-500" : "border-gray-300"}`}
                  value={formData.phone}
                  onChange={handleChange}
                />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="country">
                  Country*
                </label>
                <select
                  id="country"
                  name="country"
                  className={`w-full px-3 py-2 border rounded-md ${errors.country ? "border-red-500" : "border-gray-300"}`}
                  value={formData.country}
                  onChange={handleChange}
                >
                  <option value="">Select Country</option>
                  {countries.map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
                {errors.country && <p className="text-red-500 text-xs mt-1">{errors.country}</p>}
              </div>
            </div>

            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="address">
                Address*
              </label>
              <textarea
                id="address"
                name="address"
                rows="3"
                className={`w-full px-3 py-2 border rounded-md ${errors.address ? "border-red-500" : "border-gray-300"}`}
                value={formData.address}
                onChange={handleChange}
              ></textarea>
              {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
            </div>

            <div className="flex justify-end">
              <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700">
                Submit
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}

