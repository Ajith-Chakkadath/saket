"use client"
import { useState } from "react"
import { EyeIcon, EyeOffIcon } from "lucide-react"

export default function ResetPassword({ onResetSuccess, onBackToLogin }) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    identifier: "", // Username or email
    otp: "",
    password: "",
    confirmPassword: "",
  })

  const [errors, setErrors] = useState({})
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [resetStatus, setResetStatus] = useState(null)
  const [otpSent, setOtpSent] = useState(false)
  const [otpVerified, setOtpVerified] = useState(false)

  // Mock database for user verification
  const validUsers = [
    { username: "admin", email: "admin@example.com" },
    { username: "admin1", email: "admin1@example.com" },
    { username: "admin2", email: "admin2@example.com" },
  ]

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Clear error for this field when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      })
    }
  }

  const validateIdentifier = () => {
    const newErrors = {}

    if (!formData.identifier) {
      newErrors.identifier = "Username or email is required"
    } else {
      // Check if user exists
      const userExists = validUsers.some(
        (user) => user.username === formData.identifier || user.email === formData.identifier,
      )

      if (!userExists) {
        newErrors.identifier = "User not found"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validateOtp = () => {
    const newErrors = {}

    if (!formData.otp) {
      newErrors.otp = "OTP is required"
    } else if (formData.otp !== "123456") {
      // Mock OTP validation
      newErrors.otp = "Invalid OTP"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validatePassword = () => {
    const newErrors = {}

    if (!formData.password) {
      newErrors.password = "Password is required"
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = "Confirm password is required"
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSendOtp = () => {
    if (validateIdentifier()) {
      // Simulate sending OTP
      setTimeout(() => {
        setOtpSent(true)
      }, 1000)
    }
  }

  const handleVerifyOtp = () => {
    if (validateOtp()) {
      // Simulate OTP verification
      setTimeout(() => {
        setOtpVerified(true)
        setStep(2)
      }, 1000)
    }
  }

  const handleResetPassword = () => {
    if (validatePassword()) {
      // Simulate password reset
      setTimeout(() => {
        setResetStatus("success")

        // Redirect to login after successful reset
        setTimeout(() => {
          onResetSuccess()
        }, 2000)
      }, 1000)
    }
  }

  return (
    <div className="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">Reset Password</h2>

      {resetStatus === "success" && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          Password reset successful!
        </div>
      )}

      {resetStatus === "error" && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          Failed to reset password. Please try again.
        </div>
      )}

      {step === 1 && (
        <div>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="identifier">
              Username or Email*
            </label>
            <input
              id="identifier"
              name="identifier"
              type="text"
              className={`w-full px-3 py-2 border rounded-md ${errors.identifier ? "border-red-500" : "border-gray-300"}`}
              value={formData.identifier}
              onChange={handleChange}
              disabled={otpSent && otpVerified}
            />
            {errors.identifier && <p className="text-red-500 text-xs mt-1">{errors.identifier}</p>}
          </div>

          {otpSent && (
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="otp">
                OTP*
              </label>
              <input
                id="otp"
                name="otp"
                type="text"
                className={`w-full px-3 py-2 border rounded-md ${errors.otp ? "border-red-500" : "border-gray-300"}`}
                value={formData.otp}
                onChange={handleChange}
                disabled={otpVerified}
              />
              {errors.otp && <p className="text-red-500 text-xs mt-1">{errors.otp}</p>}
            </div>
          )}

          <div className="flex items-center justify-between">
            <button type="button" onClick={onBackToLogin} className="text-blue-500 hover:text-blue-700">
              Back to Login
            </button>

            {!otpSent ? (
              <button
                type="button"
                onClick={handleSendOtp}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
                disabled={!formData.identifier}
              >
                Send OTP
              </button>
            ) : !otpVerified ? (
              <button
                type="button"
                onClick={handleVerifyOtp}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
                disabled={!formData.otp}
              >
                Verify OTP
              </button>
            ) : null}
          </div>
        </div>
      )}

      {step === 2 && (
        <div>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="identifier-disabled">
              Username or Email
            </label>
            <input
              id="identifier-disabled"
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
              value={formData.identifier}
              disabled
            />
          </div>

          <div className="mb-4 relative">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
              New Password*
            </label>
            <div className="relative">
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                className={`w-full px-3 py-2 border rounded-md ${errors.password ? "border-red-500" : "border-gray-300"}`}
                value={formData.password}
                onChange={handleChange}
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOffIcon size={20} /> : <EyeIcon size={20} />}
              </button>
            </div>
            {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
          </div>

          <div className="mb-6 relative">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="confirmPassword">
              Confirm Password*
            </label>
            <div className="relative">
              <input
                id="confirmPassword"
                name="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                className={`w-full px-3 py-2 border rounded-md ${errors.confirmPassword ? "border-red-500" : "border-gray-300"}`}
                value={formData.confirmPassword}
                onChange={handleChange}
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <EyeOffIcon size={20} /> : <EyeIcon size={20} />}
              </button>
            </div>
            {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
          </div>

          <div className="flex items-center justify-between">
            <button type="button" onClick={() => setStep(1)} className="text-blue-500 hover:text-blue-700">
              Back
            </button>
            <button
              type="button"
              onClick={handleResetPassword}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
              disabled={!formData.password || !formData.confirmPassword}
            >
              Reset Password
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

