"use client"
import { useState } from "react"
import { EyeIcon, EyeOffIcon } from "lucide-react"

export default function AdminLogin({ onLogin, onResetPassword, onRegister }) {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  })

  const [errors, setErrors] = useState({})
  const [showPassword, setShowPassword] = useState(false)
  const [loginStatus, setLoginStatus] = useState(null)

  // Mock database for login
  const validUsers = [
    { username: "admin", password: "password123" },
    { username: "admin1", password: "password123" },
    { username: "admin2", password: "password123" },
  ]

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Clear error for this field when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      })
    }
  }

  const validateForm = () => {
    const newErrors = {}

    // Required field validation
    if (!formData.username) {
      newErrors.username = "Username is required"
    }

    if (!formData.password) {
      newErrors.password = "Password is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (validateForm()) {
      // Check if credentials are valid
      const user = validUsers.find((user) => user.username === formData.username && user.password === formData.password)

      if (user) {
        setLoginStatus("success")
        // Redirect to employee management page
        setTimeout(() => {
          onLogin()
        }, 1000)
      } else {
        setLoginStatus("error")
        setErrors({
          ...errors,
          general: "Invalid username or password",
        })
      }
    }
  }

  return (
    <div className="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">Admin Login</h2>

      {loginStatus === "error" && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          Please try again after some time!
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
            Username*
          </label>
          <input
            id="username"
            name="username"
            type="text"
            className={`w-full px-3 py-2 border rounded-md ${errors.username ? "border-red-500" : "border-gray-300"}`}
            value={formData.username}
            onChange={handleChange}
          />
          {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username}</p>}
        </div>

        <div className="mb-6 relative">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
            Password*
          </label>
          <div className="relative">
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              className={`w-full px-3 py-2 border rounded-md ${errors.password ? "border-red-500" : "border-gray-300"}`}
              value={formData.password}
              onChange={handleChange}
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOffIcon size={20} /> : <EyeIcon size={20} />}
            </button>
          </div>
          {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
        </div>

        {errors.general && (
          <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">{errors.general}</div>
        )}

        <div className="flex items-center justify-between mb-4">
          <button type="button" onClick={onResetPassword} className="text-blue-500 hover:text-blue-700">
            Reset Password
          </button>
          <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700">
            Login
          </button>
        </div>

        <div className="text-center">
          <p>
            Don't have an account?{" "}
            <button type="button" onClick={onRegister} className="text-blue-500 hover:text-blue-700">
              Register
            </button>
          </p>
        </div>
      </form>
    </div>
  )
}

